package osu.cse1223;

import java.util.Scanner;

public class Project06 {

    public static void main(String[] args) {

          int sumEven = 0;

          int sumOdd = 0;

          Scanner in = new Scanner(System.in);

          System.out.print("Enter a 16 digit credit card number (Enter a blank line to quit): ");

          String cardNumber = in.nextLine();

          if (cardNumber.isEmpty() == true) {System.out.print("Goodbye!");
             }
               else {
            	    while ((cardNumber.length())<16 || (cardNumber.length())>16){
                          System.out.println("ERROR! Number must have exactly 16 digits");
                          System.out.println("");
                          System.out.println("Enter a 16 digit credit card number (Enter a blank line to quit): ");
                          cardNumber = in.nextLine();
               }
            	    
            	    for (int i =(cardNumber.length() - 2); i > -1 ; i = i - 2) {
                       char digit = cardNumber.charAt(i);
                       int doubleDigit = Character.getNumericValue(digit)*2;
                   if (doubleDigit > 9) {
                        doubleDigit = doubleDigit -9;
                     }
                      sumEven = sumEven + doubleDigit;
               }
               for (int i=(cardNumber.length()-3);i>0;i=i-2) {
                          char digit = cardNumber.charAt(i);
                          sumOdd = (sumOdd+Character.getNumericValue(digit));
              }

               int lastDigit = Character.getNumericValue(cardNumber.charAt(cardNumber.length()-1));
               int sum = sumOdd+sumEven;
               int checkDigit = 0;
                  if (sum % 10== 0) {
                          checkDigit = 0;
               }
                 else {
                          checkDigit = 10 - (sum % 10);
               }
               while(cardNumber.length() == 16){
               System.out.println("Check digit should be: "+checkDigit);
               System.out.println("Check digit is: "+(cardNumber.charAt(cardNumber.length()-1)));
                  if (checkDigit == lastDigit){
                          System.out.print("Number is valid");
                          System.out.println("");
                          System.out.println("Enter a 16 digit credit card number (Enter a blank line to quit): ");
                          cardNumber = in.nextLine();
               }
                  else {
                          System.out.println("Number is not valid");
                          System.out.println("");
                          System.out.println("Enter a 16 digit credit card number (Enter a blank line to quit): ");
                          cardNumber = in.nextLine();
               }
                  }
                  
              }

          }
	   }



